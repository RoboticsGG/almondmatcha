#ifndef IKS4A1_H
#define IKS4A1_H

#include "LSM6DSV16X.h"
#include "STTS22H.h"
#include "LPS22DF.h"

#define IKS4A1
#endif